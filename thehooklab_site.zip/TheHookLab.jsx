export default function TheHookLab() {
  return (
    <div className="bg-[#0B0B0B] text-[#F5F5F5] min-h-screen font-sans overflow-x-hidden">
      <section className="min-h-screen flex flex-col justify-center px-6 md:px-20 py-20 border-b border-white/10">
        <div className="max-w-6xl mx-auto grid md:grid-cols-2 gap-12 items-center">
          <div>
            <p className="uppercase tracking-[0.3em] text-[#C89B3C] text-sm mb-6">
              TheHookLab
            </p>

            <h1 className="text-5xl md:text-7xl leading-none font-black uppercase mb-8">
              Good Cuts <br />
              Get Attention. <br />
              <span className="text-[#C89B3C]">Great Marketing</span> <br />
              Gets Bookings.
            </h1>
          </div>
        </div>
      </section>
    </div>
  )
}